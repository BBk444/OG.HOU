module.exports = {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
        "postcss-preset-env": {}
    }
}
