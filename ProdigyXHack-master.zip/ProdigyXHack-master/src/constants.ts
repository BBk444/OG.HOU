export const PRODIGY_X_CHEAT_MENU_ID = "prodigy-x-cheat-menu"
