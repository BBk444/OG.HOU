---
title: Prodigy X Mobile Installation
description: Learn how to install the only Prodigy hack that works on mobile - Prodigy X!
---

# Installing Prodigy X On Mobile

Watch this video to figure out how to install on your mobile devices!

![type:video](https://www.youtube.com/embed/astYzqJkg1E)

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8981394123170949"
     crossorigin="anonymous"></script>
<!-- Ad Unit 1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8981394123170949"
     data-ad-slot="1878857878"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

## Installing Prodigy D on Android

Prodigy D is a Prodigy hacking dashboard. It is very easy and quick to use. All you have to do is install the app [here](https://play.google.com/store/apps/details?id=com.HostedPosted.prodigy_d) and then open it. It's that simple!

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8981394123170949"
     crossorigin="anonymous"></script>
<!-- Ad Unit 1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8981394123170949"
     data-ad-slot="1878857878"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
