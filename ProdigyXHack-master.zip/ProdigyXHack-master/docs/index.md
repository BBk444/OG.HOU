---
title: Prodigy Hack
description: Prodigy X is the ultimate cheat menu for Prodigy. It has many features and works on all platforms.
---

<center>

# Prodigy X

![Logo](https://cdn.discordapp.com/attachments/852986451896959026/980097446589915177/IMG_3310.png)

Prodigy X is a cheat menu for the game [Prodigy](https://www.prodigygame.com/main-en/).

To use Prodigy X, go to our [installing page](installing.md).

For more help visit our [discord server](https://discord.gg/D2jUxNr39K).
</center>

!!! tip "Always use an alt, just to be safe."
    While our hacks are completely safe, **you should never use hacks on your main account.**
    There's an **extremely slim** chance that you could get banned for using hacks. If you do get banned, please [report it](https://discord.gg/D2jUxNr39K).

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8981394123170949"
     crossorigin="anonymous"></script>
<!-- Ad Unit 1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8981394123170949"
     data-ad-slot="1878857878"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
